const NotFoundPage = () => {
    return <div>Not Found Page</div>
}
export default NotFoundPage;