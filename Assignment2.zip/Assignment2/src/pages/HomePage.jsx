import TableContainerComponent from '../components/Table/TableContainerComponent';


const HomePage = () => {
    return (<div>
        <TableContainerComponent />
    </div>)
}

export default HomePage;