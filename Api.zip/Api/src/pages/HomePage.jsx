import CryptoContainerComponent from "../components/CryptoContainerComponent";


const HomePage = () => {
    return (<div>
        <CryptoContainerComponent />
    </div>)
}

export default HomePage;