const CryptoDetailPage = () => {
    return <div>CrytpoDetailPage</div>
}

export default CryptoDetailPage;